//
//  UserData.swift
//  prototipoApp
//
//  Created by Facundo on 02/11/21.
//

import UIKit

class UserData: NSObject {
    var type : String?
    var campusId : String?
    var names : String?
    var id : String?
    var current_period : Int?
    
}
