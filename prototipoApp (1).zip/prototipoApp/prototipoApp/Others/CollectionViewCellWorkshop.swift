//
//  CollectionViewCellWorkshop.swift
//  prototipoApp
//
//  Created by Alumno on 02/11/21.
//

import UIKit

class CollectionViewCellWorkshop: UICollectionViewCell {
    
    @IBOutlet weak var workshopImage: UIImageView!
    @IBOutlet weak var workshopId: UILabel!
    @IBOutlet weak var imageMask: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
}
