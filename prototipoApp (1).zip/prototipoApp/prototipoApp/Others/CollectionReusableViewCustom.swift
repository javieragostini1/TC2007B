//
//  CollectionReusableViewCustom.swift
//  prototipoApp
//
//  Created by Facundo on 08/11/21.
//

import UIKit

class CollectionReusableViewCustom: UICollectionReusableView {
        
    @IBOutlet weak var sectionNameLbl: UILabel!
}
