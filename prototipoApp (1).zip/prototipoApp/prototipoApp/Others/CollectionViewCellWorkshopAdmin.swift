//
//  CollectionViewCellWorkshopAdmin.swift
//  prototipoApp
//
//  Created by Facundo on 04/11/21.
//

import UIKit

class CollectionViewCellWorkshopAdmin: UICollectionViewCell {
    
    @IBOutlet weak var workshopImage: UIImageView!
    @IBOutlet weak var workshopId: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var imageMask: UIView!
    
}
